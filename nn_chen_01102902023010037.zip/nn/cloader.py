from torch.utils.data import Dataset, DataLoader
import torch

class CustomDataloader(Dataset):
    def __init__(self, avg, pearson, spearman, score, revenue):
        #self.matrix = matrix
        #self.scores = scores
        #self.correlations = correlations  # This should include both Pearson coefficients and p-values
        self.avg = avg
        self.pearson = pearson
        self.spearman = spearman
        self.revenue = revenue
        self.score = score
        #self.rank = rank

    def __len__(self):
        return 3

    def __getitem__(self, idx):
        
        # Constructing the full feature vector
        features = [self.avg[idx], self.pearson[idx], self.spearman[idx]]#[self.avg[idx] + [self.scores[idx]] + correlation_features] , self.score[idx], self.rank[idx]
        target = self.revenue[idx] 

        return torch.tensor(features, dtype=torch.float32), torch.tensor(target, dtype=torch.float32)
