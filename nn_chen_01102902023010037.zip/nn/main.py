import json
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from model import RegressionNN
from torch.utils.data import DataLoader
from cloader import CustomDataloader
import matplotlib.pyplot as plt
import os
os.environ['KMP_DUPLICATE_LIB_OK']='TRUE'


####################################################
def load_json_data(filepath):
    with open(filepath, 'r', encoding='utf-8') as file:
        return json.load(file)

def save_data_to_json(data, filepath):
    with open(filepath, 'w', encoding='utf-8') as file:
        json.dump(data, file, indent=4)

def load_csv_to_matrix(filename):
    df = pd.read_csv(filename)
    return df.iloc[:, 1:].values.tolist()
####################################################


def main():
    
    # Parameters
    input_size = 3 #4928
    batch_size = 64
    alpha = 0.1
    num_epochs = 1000

    # Load data
    correlation = load_json_data('category_correlations.json')
    matrix = load_csv_to_matrix('hu_distance_matrix_scaled.csv')
    hotels = load_json_data('hu_hotel_weighted.json') #load_json_data('hu_hotel_filtered.json')
    score = [hotel.get('Total Score', 0) for hotel in hotels][:-50] # for hotel in hotels
    rank = [hotel.get('Rank', 0) for hotel in hotels][:-50]
    revenue = [hotel.get('revenue', 0) for hotel in hotels][:-50]
    #print(revenue[:10])
    avg = [hotel.get('avg_distance', 0) for hotel in hotels][:-50]
    #print(avg[:10])
    pearson = [hotel.get('pearson_weighted_avg_distance', 0) for hotel in hotels][:-50]
    #print(pearson[:10])
    spearman = [hotel.get('spearman_weighted_avg_distance', 0) for hotel in hotels][:-50]
    #print(spearman[:10])

    dataset = CustomDataloader(avg, pearson, spearman, score, revenue) #matrix, scores, correlation, revenue
    data_loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

    # Model
    model = RegressionNN(input_size)

    # Loss and optimizer
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=alpha)

    #print(f"DataLoader size: {len(data_loader)}")
    if len(data_loader) == 0:
        print("DataLoader is empty. Exiting.")
        return

    # Training loop
    losses = []
    try:
        for epoch in range(num_epochs):

            loss_epoch = 0
            for i, (features, targets) in enumerate(data_loader):
                #print(f"Batch {i+1}, Epoch {epoch+1}")  # Debugging print
                #print("features: ", features)
                #print("targets: ", targets)

                # Ensure targets have the same shape as model's output
                targets = targets.view(-1, 1)

                # Forward pass
                outputs = model(features)
                #print(f"Outputs shape: {outputs.shape}, Targets shape: {targets.shape}")  # Shape check

                loss = criterion(outputs, targets)

                # Backward and optimize
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                loss_epoch = loss_epoch + loss.item()
                losses.append(loss_epoch)

            print(f'Epoch [{epoch+1}/{num_epochs}], Batch [{i+1}/{len(data_loader)}], Loss: {loss_epoch:.4f}')

    except Exception as e:
        print(f"An error occurred: {e}")


    # Save the model
    torch.save(model.state_dict(), 'model.pth')

    plt.plot(losses, linestyle='dotted')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training Loss over epochs')
    plt.show()

    ## TESTING
    #model.eval()
    test_epochs = 1000

    test_score = [hotel.get('Total Score', 0) for hotel in hotels][-50:] 
    test_revenue = [hotel.get('revenue', 0) for hotel in hotels][-50:]
    test_avg = [hotel.get('avg_distance', 0) for hotel in hotels][-50:]
    test_pearson = [hotel.get('pearson_weighted_avg_distance', 0) for hotel in hotels][-50:]
    test_spearman = [hotel.get('spearman_weighted_avg_distance', 0) for hotel in hotels][-50:]

    # Create DataLoader for test data
    test_dataset = CustomDataloader(test_avg, test_pearson, test_spearman, test_score, test_revenue)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    # Initialize list to store test losses for each epoch
    test_losses_per_epoch = []

    # Double loop structure for testing (similar to training)
    for epoch in range(test_epochs):
        epoch_losses = 0
        for i, (features, targets) in enumerate(test_loader):
            targets = targets.view(-1, 1)
            outputs = model(features)
            loss = criterion(outputs, targets)
            epoch_losses = epoch_losses + loss.item()
        test_losses_per_epoch.append(epoch_losses)

    # Plot the test losses for the single epoch
    plt.plot(test_losses_per_epoch[0], linestyle='dotted', color='red')
    plt.xlabel('Test Batch')
    plt.ylabel('Loss')
    plt.title('Test Loss per Batch in Epoch')
    plt.show()

    # Print average test loss
    print('test loss: ', test_losses_per_epoch)

if __name__ == "__main__":
    main()