import json
import numpy as np
import pandas as pd
from pygam import LinearGAM, s
import matplotlib.pyplot as plt

with open('hu_hotel_weighted.json', 'r') as file:
    hotel_revenue = json.load(file)

# All variables
ranks = [hotel['Rank'] for hotel in hotel_revenue]
total_scores = [hotel['Total Score'] for hotel in hotel_revenue]
total_room_receipts = [hotel['Total Room Receipts'] for hotel in hotel_revenue]

distance_matrix_path = 'hu_distance_matrix.csv'
distance_matrix_df = pd.read_csv(distance_matrix_path)

distance_vector_path = 'hu_distance_vector.csv'
distance_vector_df = pd.read_csv(distance_vector_path)
vector = distance_vector_df['Distance']

# Convert lists to numpy arrays for pygam
ranks = np.array(ranks)
total_scores = np.array(total_scores)

avg = np.array([hotel['avg_distance'] for hotel in hotel_revenue])
spearman = np.array([hotel['spearman_weighted_avg_distance'] for hotel in hotel_revenue])
pearson = np.array([hotel['pearson_weighted_avg_distance'] for hotel in hotel_revenue])

# Ensure the lengths match
min_length = min(len(ranks), len(total_scores))
ranks = ranks[:min_length]
total_scores = total_scores[:min_length]

# Define and fit the GAM model
gam = LinearGAM(s(0)).fit(ranks, total_scores)

# Plotting the spline
XX = gam.generate_X_grid(term=0)
plt.plot(XX, gam.partial_dependence(term=0, X=XX))
plt.plot(XX, gam.partial_dependence(term=0, X=XX, width=.95)[1], c='r', ls='--')
plt.title('Partial Dependence of Hotel Score on Rank')
plt.xlabel('Rank')
plt.ylabel('Score')
plt.show()

distance_vector = np.array(vector)
total_scores = np.array(total_scores)

# Ensure the lengths match
min_length = min(len(distance_vector), len(total_scores))
distance_vector = distance_vector[:min_length]
total_scores = total_scores[:min_length]

# Define and fit the GAM model
gam = LinearGAM(s(0)).fit(distance_vector, total_scores)

# Plotting the spline
XX = gam.generate_X_grid(term=0)
plt.plot(XX, gam.partial_dependence(term=0, X=XX))
plt.plot(XX, gam.partial_dependence(term=0, X=XX, width=.95)[1], c='r', ls='--')
plt.title('Partial Dependence of Total Score on Distance to City Center')
plt.xlabel('Distance to City Center (km)')
plt.ylabel('Total Score')
plt.show()

gam = LinearGAM(s(0)).fit(avg, ranks)

# Plotting the spline
XX = gam.generate_X_grid(term=0)
plt.plot(XX, gam.partial_dependence(term=0, X=XX))
plt.plot(XX, gam.partial_dependence(term=0, X=XX, width=.95)[1], c='r', ls='--')
plt.title('Partial Dependence of Ranks on Average Distance')
plt.xlabel('Average Distance (km)')
plt.ylabel('Ranks')
plt.show()

gam = LinearGAM(s(0)).fit(avg, total_scores)

# Plotting the spline
XX = gam.generate_X_grid(term=0)
plt.plot(XX, gam.partial_dependence(term=0, X=XX))
plt.plot(XX, gam.partial_dependence(term=0, X=XX, width=.95)[1], c='r', ls='--')
plt.title('Partial Dependence of total_scores on Average Distance')
plt.xlabel('Average Distance (km)')
plt.ylabel('total_scores')
plt.show()

gam = LinearGAM(s(0)).fit(pearson, total_scores)

# Plotting the spline
XX = gam.generate_X_grid(term=0)
plt.plot(XX, gam.partial_dependence(term=0, X=XX))
plt.plot(XX, gam.partial_dependence(term=0, X=XX, width=.95)[1], c='r', ls='--')
plt.title('Partial Dependence of total_scores on pearson')
plt.xlabel('pearson (km)')
plt.ylabel('total_scores')
plt.show()

gam = LinearGAM(s(0)).fit(spearman, total_scores)

# Plotting the spline
XX = gam.generate_X_grid(term=0)
plt.plot(XX, gam.partial_dependence(term=0, X=XX))
plt.plot(XX, gam.partial_dependence(term=0, X=XX, width=.95)[1], c='r', ls='--')
plt.title('Partial Dependence of total_scores on spearman')
plt.xlabel('spearman (km)')
plt.ylabel('total_scores')
plt.show()